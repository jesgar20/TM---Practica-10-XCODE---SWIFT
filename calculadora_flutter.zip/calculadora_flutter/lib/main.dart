import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculadora',
      home: const CalculadoraPage(),
    );
  }
}

class CalculadoraPage extends StatefulWidget {
  const CalculadoraPage({super.key});

  @override
  State<CalculadoraPage> createState() => _CalculadoraPageState();
}

class _CalculadoraPageState extends State<CalculadoraPage> {
  final TextEditingController num1Controller = TextEditingController();
  final TextEditingController num2Controller = TextEditingController();

  String resultado = "";

  double get num1 => double.tryParse(num1Controller.text) ?? 0;
  double get num2 => double.tryParse(num2Controller.text) ?? 0;

  void sumar() {
    setState(() {
      resultado = (num1 + num2).toString();
    });
  }

  void restar() {
    setState(() {
      resultado = (num1 - num2).toString();
    });
  }

  void multiplicar() {
    setState(() {
      resultado = (num1 * num2).toString();
    });
  }

  void dividir() {
    setState(() {
      if (num2 == 0) {
        resultado = "Error: división entre cero";
      } else {
        resultado = (num1 / num2).toString();
      }
    });
  }

  void potencia() {
    setState(() {
      resultado = pow(num1, num2).toString();
    });
  }

  void raizCuadrada() {
    setState(() {
      if (num1 < 0) {
        resultado = "No existe raíz cuadrada";
      } else {
        resultado = sqrt(num1).toString();
      }
    });
  }

  Widget boton(String texto, VoidCallback accion) {
    return ElevatedButton(
      onPressed: accion,
      child: Text(texto),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Calculadora Flutter"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: num1Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Primer número",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: num2Controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Segundo número",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                boton("Suma", sumar),
                boton("Resta", restar),
                boton("Multiplicar", multiplicar),
                boton("Dividir", dividir),
                boton("Potencia", potencia),
                boton("Raíz", raizCuadrada),
              ],
            ),

            const SizedBox(height: 30),

            Text(
              "Resultado: $resultado",
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            )
          ],
        ),
      ),
    );
  }
}